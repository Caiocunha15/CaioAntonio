import { useState } from 'react';

const mockImoveis = [
  {
    id: 1,
    titulo: 'Apartamento no Centro',
    descricao: '2 quartos, 1 suíte, próximo a comércios.',
    preco: 'R$ 350.000',
    imagem: 'https://via.placeholder.com/300x200',
  },
  {
    id: 2,
    titulo: 'Casa com quintal',
    descricao: '3 quartos, garagem para 2 carros.',
    preco: 'R$ 500.000',
    imagem: 'https://via.placeholder.com/300x200',
  },
];

const numeroWhatsApp = '5518988088370';

export default function App() {
  const [busca, setBusca] = useState('');
  const imoveisFiltrados = mockImoveis.filter((imovel) =>
    imovel.titulo.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <header style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <h1>Imóveis com Caio Antonio</h1>
        <p>Encontre seu imóvel ideal</p>
      </header>

      <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <input
          type="text"
          placeholder="Buscar por título..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          style={{ padding: '0.5rem', width: '300px' }}
        />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
        {imoveisFiltrados.map((imovel) => (
          <div key={imovel.id} style={{ border: '1px solid #ddd', borderRadius: '10px', overflow: 'hidden' }}>
            <img src={imovel.imagem} alt={imovel.titulo} style={{ width: '100%' }} />
            <div style={{ padding: '1rem' }}>
              <h2>{imovel.titulo}</h2>
              <p>{imovel.descricao}</p>
              <p><strong>{imovel.preco}</strong></p>
              <a
                href={`https://wa.me/${numeroWhatsApp}?text=Olá! Tenho interesse no imóvel: ${encodeURIComponent(imovel.titulo)}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: 'inline-block', marginTop: '1rem', padding: '0.5rem 1rem', background: '#25D366', color: 'white', borderRadius: '5px', textDecoration: 'none' }}
              >
                Falar no WhatsApp
              </a>
            </div>
          </div>
        ))}
      </div>

      <a
        href={`https://wa.me/${numeroWhatsApp}?text=Olá! Gostaria de mais informações sobre os imóveis.`}
        target="_blank"
        rel="noopener noreferrer"
        style={{
          position: 'fixed',
          bottom: '20px',
          right: '20px',
          backgroundColor: '#25D366',
          color: 'white',
          padding: '1rem',
          borderRadius: '50%',
          fontSize: '1.5rem',
          textAlign: 'center',
          textDecoration: 'none',
        }}
      >
        W
      </a>
    </div>
  );
}
