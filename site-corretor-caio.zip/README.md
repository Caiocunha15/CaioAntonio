# Site Corretor de Imóveis - Caio Antonio

Site moderno para apresentação de imóveis, feito com React + Vite, com deploy via GitHub Pages.

## Como rodar localmente

```bash
npm install
npm run dev
```

## Como publicar no GitHub Pages

1. Instale o pacote gh-pages:

```bash
npm install --save-dev gh-pages
```

2. Suba o projeto para o GitHub:

```bash
git init
git remote add origin https://github.com/seu-usuario/site-corretor.git
git add .
git commit -m "Primeira versão"
git push -u origin main
```

3. Faça o deploy:

```bash
npm run build
npm run deploy
```

Acesse: https://seu-usuario.github.io/site-corretor
